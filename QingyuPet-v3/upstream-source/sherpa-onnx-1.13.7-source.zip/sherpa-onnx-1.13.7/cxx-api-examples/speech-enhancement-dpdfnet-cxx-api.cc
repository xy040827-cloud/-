// cxx-api-examples/speech-enhancement-dpdfnet-cxx-api.cc
//
// Copyright (c)  2026  Xiaomi Corporation
//
// We assume you have pre-downloaded the DPDFNet model and sample test wave.
// DPDFNet models are available from either:
// https://github.com/k2-fsa/sherpa-onnx/releases/tag/speech-enhancement-models
// https://huggingface.co/Ceva-IP/DPDFNet
//
// An example command to download:
// clang-format off
/*
wget https://github.com/k2-fsa/sherpa-onnx/releases/download/speech-enhancement-models/dpdfnet_baseline.onnx
wget https://github.com/k2-fsa/sherpa-onnx/releases/download/speech-enhancement-models/inp_16k.wav
*/
// clang-format on
//
// Use dpdfnet_baseline.onnx, dpdfnet2.onnx, dpdfnet4.onnx, or dpdfnet8.onnx
// for 16 kHz downstream ASR or speech recognition.
// Use dpdfnet2_48khz_hr.onnx for 48 kHz enhancement output.

#include <chrono>  // NOLINT
#include <cstdio>
#include <iostream>
#include <string>

#include "sherpa-onnx/c-api/cxx-api.h"

int32_t main() {
  using namespace sherpa_onnx::cxx;  // NOLINT

  OfflineSpeechDenoiserConfig config;
  std::string model_filename = "./dpdfnet_baseline.onnx";
  std::string wav_filename = "./inp_16k.wav";
  std::string out_wave_filename = "./enhanced-dpdfnet.wav";
  config.model.dpdfnet.model = model_filename;
  config.model.dpdfnet.attenuation_limit_db = 12.0f;

  auto sd = OfflineSpeechDenoiser::Create(config);
  if (!sd.Get()) {
    std::cerr << "Please check your config\n";
    return -1;
  }

  Wave wave = ReadWave(wav_filename);
  if (wave.samples.empty()) {
    std::cerr << "Failed to read: '" << wav_filename << "'\n";
    return -1;
  }

  std::cout << "Started\n";
  const auto begin = std::chrono::steady_clock::now();
  auto denoised =
      sd.Run(wave.samples.data(), wave.samples.size(), wave.sample_rate);
  const auto end = std::chrono::steady_clock::now();
  std::cout << "Done\n";

  WriteWave(out_wave_filename, {denoised.samples, denoised.sample_rate});

  const float elapsed_seconds =
      std::chrono::duration_cast<std::chrono::milliseconds>(end - begin)
          .count() /
      1000.;
  float duration = wave.samples.size() / static_cast<float>(wave.sample_rate);
  float rtf = elapsed_seconds / duration;

  std::cout << "Saved to " << out_wave_filename << "\n";
  printf("Duration: %.3fs\n", duration);
  printf("Elapsed seconds: %.3fs\n", elapsed_seconds);
  printf("(Real time factor) RTF = %.3f / %.3f = %.3f\n", elapsed_seconds,
         duration, rtf);
  return 0;
}
