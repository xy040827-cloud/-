// cxx-api-examples/offline-tts-piper-cxx-api.cc
//
// Copyright (c)  2026  Xiaomi Corporation

// This file shows how to use sherpa-onnx CXX API
// for English TTS with a Piper VITS model.
//
// clang-format off
/*
Usage

wget https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-en_US-lessac-medium.tar.bz2
tar xf vits-piper-en_US-lessac-medium.tar.bz2
rm vits-piper-en_US-lessac-medium.tar.bz2

./offline-tts-piper-cxx-api

 */
// clang-format on

#include <cstdint>
#include <cstdio>
#include <string>

#include "sherpa-onnx/c-api/cxx-api.h"

static int32_t ProgressCallback(const float *samples, int32_t num_samples,
                                float progress, void *arg) {
  fprintf(stderr, "Progress: %.3f%%\n", progress * 100);
  // return 1 to continue generating
  // return 0 to stop generating
  return 1;
}

int32_t main(int32_t argc, char *argv[]) {
  using namespace sherpa_onnx::cxx;  // NOLINT
  OfflineTtsConfig config;

  config.model.vits.model =
      "./vits-piper-en_US-lessac-medium/en_US-lessac-medium.onnx";
  config.model.vits.tokens = "./vits-piper-en_US-lessac-medium/tokens.txt";
  config.model.vits.data_dir =
      "./vits-piper-en_US-lessac-medium/espeak-ng-data";

  config.model.num_threads = 1;

  // If you don't want to see debug messages, please set it to 0
  config.model.debug = true;

  std::string filename = "./generated-piper-en-cxx.wav";
  std::string text =
      "Today as always, men fall into two groups: slaves and free men. Whoever "
      "does not have two-thirds of his day for himself, is a slave, whatever "
      "he may be: a statesman, a businessman, an official, or a scholar. "
      "Friends fell out often because life was changing so fast. The easiest "
      "thing in the world was to lose touch with someone.";

  auto tts = OfflineTts::Create(config);
  GenerationConfig gen_config;
  gen_config.sid = 0;
  gen_config.speed = 1.0;  // larger -> faster in speech speed
  gen_config.silence_scale = 0.2f;

#if 0
  // If you don't want to use a callback, then please enable this branch
  GeneratedAudio audio = tts.Generate(text, gen_config);
#else
  GeneratedAudio audio = tts.Generate(text, gen_config, ProgressCallback);
#endif

  WriteWave(filename, {audio.samples, audio.sample_rate});

  fprintf(stderr, "Input text is: %s\n", text.c_str());
  fprintf(stderr, "Speaker ID is: %d\n", gen_config.sid);
  fprintf(stderr, "Saved to: %s\n", filename.c_str());

  return 0;
}
